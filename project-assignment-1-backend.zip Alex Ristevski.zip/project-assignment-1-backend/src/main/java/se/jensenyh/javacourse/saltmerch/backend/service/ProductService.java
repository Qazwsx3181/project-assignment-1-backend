package se.jensenyh.javacourse.saltmerch.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import se.jensenyh.javacourse.saltmerch.backend.repository.ProductRepository;

@Service
public class ProductService
{
    @Autowired
    ProductRepository productRepository;









}

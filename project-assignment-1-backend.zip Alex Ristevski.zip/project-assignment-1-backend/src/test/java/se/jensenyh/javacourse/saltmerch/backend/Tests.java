package se.jensenyh.javacourse.saltmerch.backend;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import se.jensenyh.javacourse.saltmerch.backend.controller.CartController;
import se.jensenyh.javacourse.saltmerch.backend.model.CartItem;
import se.jensenyh.javacourse.saltmerch.backend.service.CartService;

//@WebMvcTest(CartController.class)
//public class ControllerUnitTests extends Tests
/*{
    @Autowired
MockMvc mockMvc;

@MockBean
    CartService service;

final String baseUrl = "/api/v1/";

@Test
    void getCartItems() throws Exception{
    Mockito.when(service.getCartItems()).thenReturn();
}*/
public class Tests {
}








